-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Apr 2022 pada 09.59
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `utswf`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `drivers`
--

CREATE TABLE `drivers` (
  `id` int(10) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `series` varchar(255) NOT NULL,
  `produk` varchar(255) NOT NULL,
  `os` varchar(255) NOT NULL,
  `tipe_dw` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `drivers`
--

INSERT INTO `drivers` (`id`, `tipe`, `series`, `produk`, `os`, `tipe_dw`) VALUES
(1, 'TITAN', 'NVIDIA TITAN Series', 'NVIDIA TITAN RTX', 'Windows 10 64-bit', 'Game Reader Driver (GRD)'),
(2, 'GeForce', 'GeForce RTX 30 Series (Notebooks)', 'GeForce RTX 3080 Ti Laptop GPU', 'Windows 10 64-bit', 'Game Reader Driver (GRD)');

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` int(15) NOT NULL,
  `jenis_ware` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `tentang` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `jenis_ware`, `kategori`, `nama`, `tentang`) VALUES
(1, 'Hardware', 'Gaming and Entertainment', 'Gforce Graphics Cards', 'GeForce RTX™ 30 Series GPUs deliver the ultimate performance for gamers and creators. They’re powered by Ampere—NVIDIA’s 2nd gen RTX architecture—with new RT Cores, Tensor Cores, and streaming multiprocessors for the most realistic ray-traced graphics and'),
(2, 'Hardware', 'Cloud and Data Center', 'EGX Platform', 'The NVIDIA EGX platform delivers IT infrastructure that’s compatible with every vendor and major DevOps tool, whether enterprises are deploying with Red Hat, VMware or other leading infrastructure partners. Traditional and modern, data-intensive applicati'),
(3, 'Software', 'Application Framework', 'Automatic - DRIVE', 'The NVIDIA DRIVE® family of products for autonomous vehicle development covers everything from the car to the data center. DRIVE Hyperion is the in-car solution, a vehicle architecture that includes sensors, DRIVE AGX for compute, and software tools neces'),
(4, 'Software', 'Infrastructure', 'AI Interprise Suite', 'NVIDIA AI Enterprise is an end-to-end, cloud-native suite of AI and data analytics software that’s optimized to enable any organization to use AI. It’s certified to deploy anywhere—from the enterprise data center to the public cloud—and includes global en');

-- --------------------------------------------------------

--
-- Struktur dari tabel `technology`
--

CREATE TABLE `technology` (
  `id` int(15) NOT NULL,
  `teknologi` varchar(255) NOT NULL,
  `deskripsi` varchar(500) NOT NULL,
  `thumbnail` varchar(1000) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `technology`
--

INSERT INTO `technology` (`id`, `teknologi`, `deskripsi`, `thumbnail`, `created_at`, `updated_at`) VALUES
(1, 'BatteryBoost', 'An ultra-efficient mode that delivers the same great 30+ FPS experience, but with up to 2x longer battery life while gaming.', 'https://www.nvidia.com/content/dam/en-zz/Solutions/geforce/technologies/battery-boost/battery-boost-og-1200x627.jpg', '2022-04-26 20:43:50', '2022-04-26 21:30:32'),
(2, 'Deep Learning Super Sampling (DLSS)', 'An NVIDIA technology that lets gamers use higher resolutions and settings while still maintaining solid framerates.', 'https://i0.wp.com/www.murdockcruz.com/wp-content/uploads/2021/04/Nvidia-DLSS-Feat-2.jpg', '2022-04-26 20:43:50', '2022-04-26 21:31:27'),
(3, 'GameWorks', 'Developers need the best tools, samples, and libraries to bring their creations to life. NVIDIA\'s award winning GameWorks SDK gets them access to the best technology from the leader in visual computing.', 'https://images.anandtech.com/doci/8546/GameWorks-1-Overview-(1)_678x452.jpg', '2022-04-26 21:09:54', '2022-04-26 21:09:54'),
(4, 'G-SYNC', 'G-SYNC display technology delivers a smooth and fastest gaming experience by synchronizing display refresh rates to the GPU, eliminating screen tearing and minimizing display stutter and input lag.', 'https://www.nvidia.com/content/dam/en-zz/Solutions/geforce/geforce-gsync-product-page/nvidia-g-sync-360-hz-og-image-1200x630.jpg', '2022-04-26 21:09:54', '2022-04-26 21:32:04'),
(5, 'GPUBoost', 'A feature available on NVIDIA® GeForce® and Tesla® GPUs that boosts application performance by increasing GPU core and memory clock rates when sufficient power and thermal headroom are available.', 'https://developer-blogs.nvidia.com/wp-content/uploads/2014/11/GPUBoost_thumb.png', '2022-04-26 21:11:10', '2022-04-26 21:11:10'),
(6, 'GameStream', 'deskripsi\": \"Access your favorite games from your GeForce® GTX-powered PC on your SHIELD TV or SHIELD Tablet at an amazing 60 FPS and up to 4K HDR.', 'https://support-shield.nvidia.com/gamestream-user-guide/gamestream-image.png', '2022-04-26 21:11:10', '2022-04-26 21:11:10'),
(7, 'CUDA', 'NVIDIA CUDA® is a revolutionary parallel computing platform. As an enabling hardware and software technology, CUDA makes it possible to use the many computing cores in a graphics processor to perform general-purpose mathematical calculations, achieving dramatic speedups in computing performance.', 'https://hexatekno.com/wp-content/uploads/2019/06/cuda.jpg', '2022-04-26 21:13:04', '2022-04-26 21:13:04'),
(8, 'RTX Real-Time Ray Tracing', 'The NVIDIA RTX platform fuses ray tracing, deep learning and rasterization to fundamentally transform the creative process for content creators and developers through the NVIDIA Turing GPU architecture and support for industry leading tools and APIs.', 'https://developer.nvidia.com/sites/default/files/akamai/RTX/images/rtxplatform002.png', '2022-04-26 21:13:04', '2022-04-26 21:13:04'),
(9, 'TXAA', 'TXAA anti-aliasing creates a smoother, clearer image than any other anti-aliasing solution by combining high-quality MSAA multisample anti-aliasing, post processes, and NVIDIA-designed temporal filters.', 'https://developer.nvidia.com/sites/default/files/akamai/gamedev/images/shadowworks.jpg', '2022-04-26 21:16:06', '2022-04-26 21:16:06'),
(10, 'ShadowPlay', 'ShadowPlay is the easiest way to record and share high-quality gameplay videos, screenshots, and livestreams with your friends.', 'https://www.howtogeek.com/wp-content/uploads/2020/04/0-shadowplay-nvidia-share-overlay-in-doom-eternal.jpg?height=200p&trim=2,2,2,2', '2022-04-26 21:16:06', '2022-04-26 21:16:06');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `technology`
--
ALTER TABLE `technology`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `technology`
--
ALTER TABLE `technology`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
