<?php

namespace App\Models;

use CodeIgniter\Model;

class dModel extends Model
{
    protected $table = 'drivers';
}