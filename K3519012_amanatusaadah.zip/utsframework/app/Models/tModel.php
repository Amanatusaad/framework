<?php

namespace App\Models;

use CodeIgniter\Model;

class tModel extends Model
{
    protected $table = 'technology';
}