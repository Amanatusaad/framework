<?= $this->extend('Home/index'); ?>

<?= $this->section('content'); ?>

<div class="text-left tab-text-left">
    <h3 class="title color-brand-green">NVIDIA COOPERTATION</h3>
    <div class="body-text description-color-black">
        <p>2788 San Tomas Expressway
            <br> Santa Clara, CA 95051
        </p>
        <p>
        Tel: +1 (408) 486-2000
        <br>info@nvidia.com
        </p>
        <p>
            <strong>Investor Inquiries:</strong>
            <br> (877) 7-NVIDIA
        </p>
        <p>
            <strong>Product Support:</strong>
            <br>Visit our Support page or chat 
            <br>with a Customer Care agent
        </p>
    </div>
</div>

<?= $this->endSection('content'); ?>