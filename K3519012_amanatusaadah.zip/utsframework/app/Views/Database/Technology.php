<?= $this->extend('Home/index'); ?>

<?= $this->section('content'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Tables</h1>
                    <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>TEKNOLOGI</th>
                                            <th>DESKRIPSI</th>
                                            <th>THUMBNAIL</th>
                                            <th>CREATED AT</th>
                                            <th>UPDATED AT</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($tekno as $t) : ?>
                                        <tr>
                                            <td><?= $t['id']; ?></td>
                                            <td><?=$t['teknologi']; ?></td>
                                            <td><?= $t['deskripsi']; ?></td>
                                            <td><?= $t['thumbnail']; ?></td>
                                            <td><?=$t['created_at']; ?></td>
                                            <td><?= $t['updated_at']?></td>
                                        </tr>
                                        <?php endforeach ; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

<?= $this->endSection('content'); ?>