<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Web NVIDIA | UAS K3519012'
        ];
        return view('Home/Dashboard', $data);
    }
    public function Contact()
    {
        $data = [
            'title' => 'Contact Us'
        ];
        return view('Home/Contact', $data);
    }
    public function Profile()
    {
        $data = [
            'title' => 'About Us'
        ];
        return view('Home/Profile', $data);
    }
}
