<?php

namespace App\Controllers;

use App\Models\dModel;
use App\Models\pModel;
use App\Models\tModel;

class Database extends BaseController
{
    protected $dModel;
    protected $tModel;
    public function __construct()
    {
        $this->dModel = new dModel();
        $this->tModel = new tModel();
        $this->pModel = new pModel();
    }
    public function driver()
    {   
        $drive = $this->dModel->findAll();

        $data = [
            'title' => 'Web NVIDIA | DRIVERS',
            'drive' => $drive
        ];

        return view('Database/Drivers', $data);
   }
   public function tekno()
    {   
        $tekno = $this->tModel->findAll();

        $data = [
            'title' => 'Web NVIDIA | TECHNOLOGY',
            'tekno' => $tekno
        ];
         
        return view('Database/Technology', $data);
   }
   public function produk()
    {   
        $produk = $this->pModel->findAll();

        $data = [
            'title' => 'Web NVIDIA | PRODUCTS',
            'produk' => $produk
        ];
         
        return view('Database/Product', $data);
   }
}
